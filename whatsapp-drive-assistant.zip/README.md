# WhatsApp-Driven Google Drive Assistant

n8n workflow to manage Google Drive from WhatsApp commands.

## Features
- LIST /<folder> — lists files in folder
- DELETE /<folder>/<file> — deletes file
- MOVE /<src>/<file> /<dest> — moves file
- SUMMARY /<folder> — returns summaries of each file

## Setup
1. Import `workflow.json` into n8n.
2. Set up Twilio Sandbox for WhatsApp and point it to your n8n webhook.
3. Configure Google Drive OAuth2 credentials.
4. Add your OpenAI API key for summaries.
5. Deploy and test via WhatsApp.

## Safety
- Delete requires confirmation keyword.
- Actions are logged to Google Sheets.
